function mostrar()
{

	var numero = prompt("ingrese un número entre 0 y 10.");


}//FIN DE LA FUNCIÓN