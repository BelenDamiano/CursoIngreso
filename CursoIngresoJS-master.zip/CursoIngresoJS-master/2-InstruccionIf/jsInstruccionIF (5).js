function mostrar()
{
//tomo la edad  
var edad;
edad = parseInt(document.getElementById("edad").value);

if (edad <= 13 ) {
    alert("No es adolescente");
  } else {
    if (edad >= 17 ) {
        alert("No  es adolescente");}
  }

}//FIN DE LA FUNCIÓN
/*Al ingresar una edad solo debemos informar si la persona NO es adolescente.*/