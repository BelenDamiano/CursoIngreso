function mostrar()
{
//tomo la edad  
var edad;
edad = parseInt(document.getElementById("edad").value);

if (edad >= 18) {
    alert("Es mayor de edad");}
    else if (edad < 13) {
        alert("Es un niño");
      }
      else {
        if (edad >= 13 ) {
            alert("Es adolescente");
        } else {
          if (edad <= 17 ) {
              alert("Es adolescente");}
        }
      }
            
}//FIN DE LA FUNCIÓN

/*Al ingresar una edad debemos informar si la persona es mayor de edad (mas de 18 años) 
o adolescente (entre 13 y 17 años) 
o niño (menor a 13 años).*/ /*if (edad >= 13 ) {
            alert("Es adolescente");
        } else {
          if (edad <= 17 ) {
              alert("Es adolescente");}
        }
        else(edad < 13);
        {
            alert("Es un niño");} */