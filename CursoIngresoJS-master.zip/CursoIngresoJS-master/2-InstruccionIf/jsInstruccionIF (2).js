function mostrar()
{
//tomo la edad  
var edad;
edad = parseInt(document.getElementById("edad").value);

if (edad > 18) {
    alert("Es mayor de edad");}

}//FIN DE LA FUNCIÓN
/*Al ingresar una edad debemos informar solo si la persona es mayor de edad*/