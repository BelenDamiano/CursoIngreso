function mostrar()
{
//tomo la edad  
var edad;
edad = parseInt(document.getElementById("edad").value);

if (edad > 18) {
    alert("Es mayor de edad");
  } else {
    alert("Es Menor de edad");
  }

}//FIN DE LA FUNCIÓN
/*if (hour < 18) {
  greeting = "Good day";
} else {
  greeting = "Good evening";
}
Al ingresar una edad debemos 
informar si la persona es mayor de edad, sino informar que es un menor de edad.*/