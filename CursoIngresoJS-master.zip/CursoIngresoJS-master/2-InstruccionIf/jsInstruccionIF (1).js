function mostrar()
{
//tomo la edad  
var edad;
edad = parseInt(document.getElementById("edad").value);

if (edad == 15);
    {
        alert("Niña Bonita");
    }
   
}//FIN DE LA FUNCIÓN
/*Al ingresar una edad que sea igual a 15, mostrar el mensaje "niña bonita".*/