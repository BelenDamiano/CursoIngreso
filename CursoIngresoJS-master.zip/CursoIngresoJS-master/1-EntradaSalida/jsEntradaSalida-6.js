/*Debemos lograr tomar Los numeros por ID ,
transformarlos a enteros (parseInt) y Sumarlos.
mostrar el resulto por medio de "ALERT"
Debemos lograr tomar Los numeros por ID , transformarlos a enteros (parseInt) y Sumarlos. 
mostrar el resulto por medio de "ALERT"
ej.: "la suma es 750" "numeroUno"*/
function sumar()
{
    var numero1
    var numero2

    numero1 = parseInt(document.getElementById("numeroUno").value);
    numero2 = parseInt(document.getElementById("numeroDos").value);

    alert("La Suma es " + (numero1 + numero2)); 

}

