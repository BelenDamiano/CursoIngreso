
function mostrar()
{
    var ancho;    
    ancho = parseInt(prompt("Ingrese Ancho:"));
    var largo;
    largo = parseInt(prompt("Ingrese Largo:"));
    
    var perimetro

    perimetro = (ancho + largo)*2;

    alert(perimetro);


}
