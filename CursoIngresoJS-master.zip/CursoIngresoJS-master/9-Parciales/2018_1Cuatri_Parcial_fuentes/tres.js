function mostrar()
{
    var precio
    precio = parseInt(prompt("Ingrese Precio:"));
    
    var porcentaje
    porcentaje = parseInt(prompt("Ingrese Descuento:"));

    var precioFinal
    precioFinal = precio - (precio * (porcentaje / 100));

    document.getElementById("elPrecioFinal").value = precioFinal;
}
/*Bienvenidos. 
Pedir por prompt el precio y el porcentaje de descuento, 
mostrar el precio final con descuento por id.*/