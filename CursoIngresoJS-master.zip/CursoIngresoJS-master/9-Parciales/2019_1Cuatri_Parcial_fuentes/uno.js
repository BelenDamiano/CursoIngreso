
function mostrar()
{
var ancho;
var largo;

ancho = prompt("Ingrese Ancho:");
largo = prompt("Ingrese Largo:");

parseInt(ancho);
parseInt(largo);

var perimetro

perimetro = (ancho + largo)*2;

alert(perimetro);

}
/*Realizar el algoritmo que pida el ancho 
y el largo de un rectángulo por prompt y que muestre el perímetro por alert.*/